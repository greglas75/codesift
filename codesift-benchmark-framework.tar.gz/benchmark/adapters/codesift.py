"""
CodeSift adapter — maps benchmark tasks to codesift CLI commands.

Each task category maps to specific CodeSift tools:
  text       → search_text / search_patterns
  symbol     → search_symbols / find_and_show
  structure  → get_file_tree / get_file_outline / analyze_complexity
  retrieval  → get_symbol / get_context_bundle / codebase_retrieval
  relationship → find_references / trace_call_chain / impact_analysis
  semantic   → codebase_retrieval (semantic mode)
  analysis   → find_dead_code / find_clones / analyze_hotspots
"""

import json
from .base import ToolAdapter, TaskResult


class CodeSiftAdapter(ToolAdapter):

    @property
    def adapter_id(self) -> str:
        return "codesift"

    def setup(self, repo_path: str) -> None:
        """Index repo if not already indexed."""
        call = self.run_command(["codesift", "index", repo_path], timeout=300)
        if call.returncode != 0:
            raise RuntimeError(f"CodeSift index failed: {call.stderr[:500]}")

    def execute_task(self, repo_path: str, task: dict) -> TaskResult:
        result = self.make_result(task, repo_id="")
        category = task["category"]
        question = task["question"]

        # Map category → CodeSift command(s)
        strategy = getattr(self, f"_strategy_{category}", None)
        if not strategy:
            result.error = f"No strategy for category: {category}"
            return result

        try:
            strategy(repo_path, task, result)
            result.compute_aggregates()
        except Exception as e:
            result.error = str(e)

        return result

    # ----- Category strategies -----

    def _strategy_text(self, repo_path: str, task: dict, result: TaskResult):
        """Text search — use search_text or search_patterns."""
        task_id = task["id"]
        question = task["question"]

        # Specific patterns for known tasks
        patterns = {
            "text-001": ("search", ["codesift", "search", f"local/{self._repo_name(repo_path)}", "TODO|FIXME", "--file-pattern", "!*.test.*"]),
            "text-003": ("patterns", ["codesift", "patterns", f"local/{self._repo_name(repo_path)}", "empty-catch"]),
            "text-004": ("patterns", ["codesift", "patterns", f"local/{self._repo_name(repo_path)}", "console-log"]),
            "text-005": ("patterns", ["codesift", "patterns", f"local/{self._repo_name(repo_path)}", "any-type"]),
        }

        if task_id in patterns:
            _, cmd = patterns[task_id]
            call = self.run_command(cmd)
            result.calls.append(call)
            result.raw_output = call.stdout
            result.success = call.returncode == 0
        else:
            # Generic: use semantic retrieval for text tasks
            query = json.dumps([{"type": "text", "query": question, "top_k": 50}])
            call = self.run_command([
                "codesift", "retrieve", f"local/{self._repo_name(repo_path)}",
                "--queries", query
            ])
            result.calls.append(call)
            result.raw_output = call.stdout
            result.success = call.returncode == 0

    def _strategy_symbol(self, repo_path: str, task: dict, result: TaskResult):
        """Symbol search — use search_symbols."""
        question = task["question"]

        # Extract likely search terms from question
        call = self.run_command([
            "codesift", "symbols", f"local/{self._repo_name(repo_path)}",
            question, "--detail", "compact", "--token-budget", "4000"
        ])
        result.calls.append(call)
        result.raw_output = call.stdout
        result.success = call.returncode == 0

    def _strategy_structure(self, repo_path: str, task: dict, result: TaskResult):
        """Structure — use file tree, outline, or complexity."""
        task_id = task["id"]

        if task_id == "structure-001":
            call = self.run_command([
                "codesift", "tree", f"local/{self._repo_name(repo_path)}",
                "--depth", "2"
            ])
        elif task_id == "structure-002":
            call = self.run_command([
                "codesift", "complexity", f"local/{self._repo_name(repo_path)}"
            ])
        elif task_id == "structure-003":
            call = self.run_command([
                "codesift", "symbols", f"local/{self._repo_name(repo_path)}",
                "route handler endpoint", "--detail", "compact"
            ])
        elif task_id == "structure-004":
            call = self.run_command([
                "codesift", "search", f"local/{self._repo_name(repo_path)}",
                "export.*from", "--file-pattern", "index.*"
            ])
        else:
            call = self.run_command([
                "codesift", "repo-outline", f"local/{self._repo_name(repo_path)}"
            ])

        result.calls.append(call)
        result.raw_output = call.stdout
        result.success = call.returncode == 0

    def _strategy_retrieval(self, repo_path: str, task: dict, result: TaskResult):
        """Code retrieval — use context-bundle or codebase_retrieval."""
        question = task["question"]
        query = json.dumps([{"type": "hybrid", "query": question, "top_k": 8}])

        call = self.run_command([
            "codesift", "retrieve", f"local/{self._repo_name(repo_path)}",
            "--queries", query
        ])
        result.calls.append(call)
        result.raw_output = call.stdout
        result.success = call.returncode == 0

    def _strategy_relationship(self, repo_path: str, task: dict, result: TaskResult):
        """Relationship tracing — use trace, refs, impact, communities."""
        task_id = task["id"]
        repo_name = self._repo_name(repo_path)

        if task_id == "relationship-005":
            # Circular dependencies → knowledge-map
            call = self.run_command([
                "codesift", "knowledge-map", f"local/{repo_name}"
            ])
        elif task_id == "relationship-003":
            # Impact analysis
            query = json.dumps([{"type": "hybrid", "query": task["question"], "top_k": 10}])
            call = self.run_command([
                "codesift", "retrieve", f"local/{repo_name}", "--queries", query
            ])
        else:
            # Generic trace
            query = json.dumps([{"type": "hybrid", "query": task["question"], "top_k": 10}])
            call = self.run_command([
                "codesift", "retrieve", f"local/{repo_name}", "--queries", query
            ])

        result.calls.append(call)
        result.raw_output = call.stdout
        result.success = call.returncode == 0

    def _strategy_semantic(self, repo_path: str, task: dict, result: TaskResult):
        """Semantic search — use codebase_retrieval in semantic mode."""
        question = task["question"]
        query = json.dumps([{"type": "semantic", "query": question, "top_k": 10}])

        call = self.run_command([
            "codesift", "retrieve", f"local/{self._repo_name(repo_path)}",
            "--queries", query
        ])
        result.calls.append(call)
        result.raw_output = call.stdout
        result.success = call.returncode == 0

    def _strategy_analysis(self, repo_path: str, task: dict, result: TaskResult):
        """Analysis — dead code, clones, hotspots."""
        task_id = task["id"]
        repo_name = self._repo_name(repo_path)

        if task_id == "analysis-001":
            call = self.run_command(["codesift", "dead-code", f"local/{repo_name}"])
        elif task_id == "analysis-002":
            call = self.run_command(["codesift", "clones", f"local/{repo_name}"])
        elif task_id == "analysis-003":
            call = self.run_command(["codesift", "hotspots", f"local/{repo_name}"])
        else:
            call = self.run_command(["codesift", "complexity", f"local/{repo_name}"])

        result.calls.append(call)
        result.raw_output = call.stdout
        result.success = call.returncode == 0

    # ----- Helpers -----

    @staticmethod
    def _repo_name(repo_path: str) -> str:
        """Extract repo name from path for codesift local/ prefix."""
        return repo_path.rstrip("/").split("/")[-1]
